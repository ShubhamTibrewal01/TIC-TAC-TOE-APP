# TicTacToeInAndroidStudio
This is Tic Tac Toe Game which created in Android Studio Using Java

This is the basic design of App in Playing Condition


![image](https://user-images.githubusercontent.com/64765400/111019763-1d8b9a80-8376-11eb-86ea-99869b8229a4.png)



It also contains the logic if no one wins then how to handle condtion

![image](https://user-images.githubusercontent.com/64765400/111019765-21b7b800-8376-11eb-9ea7-a549924877b5.png)

It Can increment the score if someone wins

![image](https://user-images.githubusercontent.com/64765400/111019769-254b3f00-8376-11eb-8c1f-6583d13ab194.png)



The design is very sleek and it contains reset button to reset everything

![image](https://user-images.githubusercontent.com/64765400/111019781-29775c80-8376-11eb-9fe3-53e21ed89e5e.png)



It Contains A Beautiful Splash Screen

![image](https://user-images.githubusercontent.com/64765400/111019784-2da37a00-8376-11eb-9077-265724237a1d.png)

